var myVar = context.getVariable("jokeresponse.body");
myVar = myVar.replace("\\n","\\\\n","g");

context.setVariable("jokeresponse.body",myVar);